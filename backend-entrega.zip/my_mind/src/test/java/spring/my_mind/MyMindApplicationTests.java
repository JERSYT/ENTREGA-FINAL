package spring.my_mind;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMindApplicationTests {

	@Test
	void contextLoads() {
	}

}
