package spring.my_mind.models.enums;

/**
 * Enumeración que define las posibles etiquetas de una tarea.
 */
public enum Etiqueta {
    Urgente,
    Importante,
    Secundario
}
