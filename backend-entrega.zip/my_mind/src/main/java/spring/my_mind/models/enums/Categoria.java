package spring.my_mind.models.enums;

/**
 * Enumeración que representa las posibles categorías de una tarea.
 */
public enum Categoria {
    Personal,
    Trabajo,
    Estudio,
    Finanzas,
    Eventos,
    Notas_rapidas
}
