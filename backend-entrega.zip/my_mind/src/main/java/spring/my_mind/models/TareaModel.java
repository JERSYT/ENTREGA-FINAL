package spring.my_mind.models;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import spring.my_mind.models.enums.Categoria;
import spring.my_mind.models.enums.Etiqueta;

/**
 * Clase que representa la entidad Tarea en la base de datos.
 */
@Entity
@Table(name = "tarea")
public class TareaModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private Long id;

    @Column(name = "titulo")
    private String titulo;

    @Column(name = "contenido")
    private String contenido;

    @Column(name = "color")
    private String color;

    @Column(name = "fechaRecordatorio")
    private LocalDateTime fechaRecordatorio;

    @Column(name = "fechaCreacion")
    private LocalDateTime fechaCreacion;

    @Enumerated(EnumType.STRING)
    private Etiqueta etiqueta;

    @Enumerated(EnumType.STRING)
    private Categoria categoria;

    @ManyToOne()
    @JoinColumn(name = "usuario")
    private UsuarioModel usuario;

    /**
     * Obtiene el ID de la tarea.
     * @return El ID de la tarea.
     */
    public Long getId() {
        return id;
    }

    /**
     * Establece el ID de la tarea.
     * @param id El nuevo ID de la tarea.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Obtiene el título de la tarea.
     * @return El título de la tarea.
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Establece el título de la tarea.
     * @param titulo El nuevo título de la tarea.
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene el contenido de la tarea.
     * @return El contenido de la tarea.
     */
    public String getContenido() {
        return contenido;
    }

    /**
     * Establece el contenido de la tarea.
     * @param contenido El nuevo contenido de la tarea.
     */
    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    /**
     * Obtiene el color de la tarea.
     * @return El color de la tarea.
     */
    public String getColor() {
        return color;
    }

    /**
     * Establece el color de la tarea.
     * @param color El nuevo color de la tarea.
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Obtiene la fecha de recordatorio de la tarea.
     * @return La fecha de recordatorio de la tarea.
     */
    public LocalDateTime getFechaRecordatorio() {
        return fechaRecordatorio;
    }

    /**
     * Establece la fecha de recordatorio de la tarea.
     * @param fechaRecordatorio La nueva fecha de recordatorio de la tarea.
     */
    public void setFechaRecordatorio(LocalDateTime fechaRecordatorio) {
        this.fechaRecordatorio = fechaRecordatorio;
    }

    /**
     * Obtiene la fecha de creación de la tarea.
     * @return La fecha de creación de la tarea.
     */
    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    /**
     * Establece la fecha de creación de la tarea.
     * @param fechaCreacion La nueva fecha de creación de la tarea.
     */
    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    /**
     * Obtiene la etiqueta de la tarea.
     * @return La etiqueta de la tarea.
     */
    public Etiqueta getEtiqueta() {
        return etiqueta;
    }

    /**
     * Establece la etiqueta de la tarea.
     * @param etiqueta La nueva etiqueta de la tarea.
     */
    public void setEtiqueta(Etiqueta etiqueta) {
        this.etiqueta = etiqueta;
    }

    /**
     * Obtiene la categoría de la tarea.
     * @return La categoría de la tarea.
     */
    public Categoria getCategoria() {
        return categoria;
    }

    /**
     * Establece la categoría de la tarea.
     * @param categoria La nueva categoría de la tarea.
     */
    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    /**
     * Obtiene el usuario asociado a la tarea.
     * @return El usuario asociado a la tarea.
     */
    public UsuarioModel getUsuario() {
        return usuario;
    }

    /**
     * Establece el usuario asociado a la tarea.
     * @param usuario El nuevo usuario asociado a la tarea.
     */
    public void setUsuario(UsuarioModel usuario) {
        this.usuario = usuario;
    }
}
