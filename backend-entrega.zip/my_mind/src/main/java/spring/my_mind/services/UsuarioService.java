package spring.my_mind.services;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.my_mind.models.UsuarioModel;
import spring.my_mind.repositories.UsuarioRepository;

/**
 * Servicio que proporciona operaciones relacionadas con la gestión de usuarios.
 */
@Service
public class UsuarioService {

    @Autowired
    UsuarioRepository usuarioRepository;

    /**
     * Inicia sesión de un usuario proporcionando correo y contraseña.
     *
     * @param correo    El correo del usuario.
     * @param password  La contraseña del usuario.
     * @return Un Optional que contiene al usuario si se encuentra, o vacío si no.
     */
    public Optional<UsuarioModel> iniciarSesion(String correo, String password) {
        return usuarioRepository.findByCorreoAndPassword(correo, password);
    }

    /**
     * Crea o actualiza un usuario en la base de datos.
     *
     * @param usuario El usuario a crear o actualizar.
     * @return El usuario creado o actualizado.
     */
    public UsuarioModel createUsuario(UsuarioModel usuario) {
        return usuarioRepository.save(usuario);
    }

    /**
     * Obtiene todos los usuarios almacenados en la base de datos.
     *
     * @return Una lista de todos los usuarios.
     */
    public ArrayList<UsuarioModel> readUsuarios() {
        return (ArrayList<UsuarioModel>) usuarioRepository.findAll();
    }

    /**
     * Obtiene un usuario por su ID.
     *
     * @param id El ID del usuario.
     * @return Un Optional que contiene al usuario si se encuentra, o vacío si no.
     */
    public Optional<UsuarioModel> readUsuarioById(Long id) {
        return usuarioRepository.findById(id);
    }

    /**
     * Elimina un usuario por su ID.
     *
     * @param id El ID del usuario a eliminar.
     * @return true si el usuario se eliminó correctamente, false en caso contrario.
     */
    public boolean deleteUsuario(Long id) {
        try {
            usuarioRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
