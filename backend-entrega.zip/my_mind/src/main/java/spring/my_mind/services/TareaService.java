package spring.my_mind.services;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.my_mind.models.TareaModel;
import spring.my_mind.models.UsuarioModel;
import spring.my_mind.repositories.TareaRepository;

/**
 * Servicio que proporciona operaciones relacionadas con la gestión de tareas.
 */
@Service
public class TareaService {

    @Autowired
    TareaRepository tareaRepository;

    @Autowired
    private UsuarioService usuarioService;

    /**
     * Obtiene todas las tareas asociadas a un usuario.
     *
     * @param usuario El usuario para el cual se buscan las tareas.
     * @return Una lista de tareas asociadas al usuario.
     */
    public List<TareaModel> tareasPorUsuario(UsuarioModel usuario) {
        return tareaRepository.findByUsuario(usuario);
    }

    /**
     * Crea o actualiza una tarea en la base de datos.
     *
     * @param tarea La tarea a crear o actualizar.
     * @return La tarea creada o actualizada.
     */
    public TareaModel createTarea(TareaModel tarea) {
        return tareaRepository.save(tarea);
    }

    /**
     * Obtiene todas las tareas almacenadas en la base de datos.
     *
     * @return Una lista de todas las tareas.
     */
    public ArrayList<TareaModel> readTareas() {
        return (ArrayList<TareaModel>) tareaRepository.findAll();
    }

    /**
     * Obtiene una tarea por su ID.
     *
     * @param id El ID de la tarea.
     * @return Un Optional que contiene la tarea si se encuentra, o vacío si no.
     */
    public Optional<TareaModel> readTareasById(Long id) {
        return tareaRepository.findById(id);
    }

    /**
     * Obtiene todas las tareas asociadas a un usuario por su ID.
     *
     * @param usuarioId El ID del usuario para el cual se buscan las tareas.
     * @return Una lista de tareas asociadas al usuario.
     * @throws NoSuchElementException Si no se encuentra el usuario con el ID proporcionado.
     */
    public List<TareaModel> obtenerTareasPorUsuario(Long usuarioId) {
        Optional<UsuarioModel> optionalUsuario = usuarioService.readUsuarioById(usuarioId);

        if (optionalUsuario.isPresent()) {
            UsuarioModel usuario = optionalUsuario.get();
            return tareaRepository.findByUsuario(usuario);
        } else {
            throw new NoSuchElementException("Usuario no encontrado con el ID: " + usuarioId);
        }
    }

    /**
     * Elimina una tarea por su ID.
     *
     * @param id El ID de la tarea a eliminar.
     * @return true si la tarea se eliminó correctamente, false en caso contrario.
     */
    public boolean deleteTarea(Long id) {
        try {
            tareaRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
