package spring.my_mind.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import spring.my_mind.models.TareaModel;
import spring.my_mind.services.TareaService;

/**
 * Controlador que gestiona las operaciones relacionadas con las tareas.
 */
@RestController
@RequestMapping("/api/v1/tarea")
@CrossOrigin("*")
public class TareaController {
    @Autowired
    TareaService tareaService;

    /**
     * Crea una nueva tarea.
     * @param tarea Objeto TareaModel que representa la nueva tarea.
     * @return La tarea creada.
     */
    @PostMapping()
    public TareaModel createTarea(@RequestBody TareaModel tarea) {
        return this.tareaService.createTarea(tarea);
    }

    /**
     * Obtiene todas las tareas.
     * @return Lista de todas las tareas.
     */
    @GetMapping()
    public ArrayList<TareaModel> readTareas() {
        return tareaService.readTareas();
    }

    /**
     * Obtiene una tarea por su ID.
     * @param id ID de la tarea.
     * @return La tarea correspondiente al ID proporcionado.
     */
    @GetMapping("/{id}")
    public Optional<TareaModel> readTareasById(@PathVariable("id") Long id) {
        return this.tareaService.readTareasById(id);
    }

    /**
     * Obtiene las tareas asociadas a un usuario específico.
     * @param usuarioId ID del usuario.
     * @return Lista de tareas asociadas al usuario.
     */
    @GetMapping("/usuario/{usuarioId}")
    public List<TareaModel> obtenerTareasPorUsuario(@PathVariable Long usuarioId) {
        return tareaService.obtenerTareasPorUsuario(usuarioId);
    }

    /**
     * Elimina una tarea por su ID.
     * @param id ID de la tarea a eliminar.
     * @return Mensaje indicando el resultado de la operación.
     */
    @DeleteMapping("/{id}")
    public String deleteTarea(@PathVariable("id") Long id) {
        boolean ok = this.tareaService.deleteTarea(id);
        if (ok) {
            return "Tarea eliminada";
        } else {
            return "No se pudo eliminar la tarea";
        }
    }
}
