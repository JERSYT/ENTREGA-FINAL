package spring.my_mind.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import spring.my_mind.models.UsuarioModel;
import spring.my_mind.services.UsuarioService;

/**
 * Controlador que gestiona las operaciones relacionadas con los usuarios.
 */
@RestController
@RequestMapping("/api/v1/usuario")
@CrossOrigin("*")
public class UsuarioController {
    @Autowired
    UsuarioService usuarioService;

    /**
     * Inicia sesión de usuario.
     * @param loginRequest Objeto UsuarioModel que contiene las credenciales de inicio de sesión.
     * @return ResponseEntity que indica el resultado del inicio de sesión.
     */
    @PostMapping("/login")
    public ResponseEntity<Object> login(@RequestBody UsuarioModel loginRequest) {
        String correo = loginRequest.getCorreo();
        String password = loginRequest.getPassword();

        Optional<UsuarioModel> usuarioOptional = usuarioService.iniciarSesion(correo, password);

        if (usuarioOptional.isPresent()) {
            UsuarioModel usuario = usuarioOptional.get();

            // Inicio de sesión exitoso
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Inicio de sesión exitoso");
            response.put("status", "200");
            response.put("usuario", usuario);
            return ResponseEntity.ok().body(response);
        } else {
            // Usuario no encontrado o contraseña incorrecta
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Credenciales inválidas");
            errorResponse.put("status", "500");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    /**
     * Crea un nuevo usuario.
     * @param usuario Objeto UsuarioModel que representa al nuevo usuario.
     * @return El usuario creado.
     */
    @PostMapping()
    public UsuarioModel createUsuario(@RequestBody UsuarioModel usuario) {
        return this.usuarioService.createUsuario(usuario);
    }

    /**
     * Obtiene todos los usuarios.
     * @return Lista de todos los usuarios.
     */
    @GetMapping()
    public ArrayList<UsuarioModel> readUsuarios() {
        return usuarioService.readUsuarios();
    }

    /**
     * Obtiene un usuario por su ID.
     * @param id ID del usuario.
     * @return El usuario correspondiente al ID proporcionado.
     */
    @GetMapping("/{id}")
    public Optional<UsuarioModel> readUsuarioById(@PathVariable("id") Long id) {
        return this.usuarioService.readUsuarioById(id);
    }

    /**
     * Elimina un usuario por su ID.
     * @param id ID del usuario a eliminar.
     * @return Mensaje indicando el resultado de la operación.
     */
    @DeleteMapping("/{id}")
    public String deleteUsuario(@PathVariable("id") Long id) {
        boolean ok = this.usuarioService.deleteUsuario(id);
        if (ok) {
            return "Usuario eliminado";
        } else {
            return "No se pudo eliminar el usuario";
        }
    }
}
