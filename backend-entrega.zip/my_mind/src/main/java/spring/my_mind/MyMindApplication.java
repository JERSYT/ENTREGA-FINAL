package spring.my_mind;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal que inicia la aplicación MyMind.
 */
@SpringBootApplication
public class MyMindApplication {

    /**
     * Método principal que inicia la aplicación Spring Boot.
     * @param args Argumentos de línea de comandos.
     */
    public static void main(String[] args) {
        // Configuración del puerto del servidor
        System.setProperty("server.port", "8092");
        
        // Inicia la aplicación Spring Boot
        SpringApplication.run(MyMindApplication.class, args);
    }
}
