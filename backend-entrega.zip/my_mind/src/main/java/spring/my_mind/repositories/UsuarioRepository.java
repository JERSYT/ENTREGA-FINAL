package spring.my_mind.repositories;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import spring.my_mind.models.UsuarioModel;

/**
 * Interfaz que proporciona métodos para acceder y gestionar datos de usuarios en la base de datos.
 */
@Repository
public interface UsuarioRepository extends CrudRepository<UsuarioModel, Long> {

    /**
     * Busca un usuario por su correo electrónico y contraseña.
     *
     * @param correo   El correo electrónico del usuario.
     * @param password La contraseña del usuario.
     * @return Un Optional que contiene el usuario si se encuentra, o vacío si no.
     */
    Optional<UsuarioModel> findByCorreoAndPassword(String correo, String password);
}
