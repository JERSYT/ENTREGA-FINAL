package spring.my_mind.repositories;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import spring.my_mind.models.TareaModel;
import spring.my_mind.models.UsuarioModel;

/**
 * Interfaz que proporciona métodos para acceder y gestionar datos de tareas en la base de datos.
 */
@Repository
public interface TareaRepository extends CrudRepository<TareaModel, Long> {

    /**
     * Obtiene una lista de tareas por su título.
     *
     * @param titulo El título de la tarea.
     * @return Una lista de tareas que coinciden con el título.
     */
    public abstract ArrayList<TareaModel> readTareasByTitulo(String titulo);

    /**
     * Obtiene una lista de tareas asociadas a un usuario específico.
     *
     * @param usuario El usuario al que están asociadas las tareas.
     * @return Una lista de tareas asociadas al usuario.
     */
    List<TareaModel> findByUsuario(UsuarioModel usuario);
}
